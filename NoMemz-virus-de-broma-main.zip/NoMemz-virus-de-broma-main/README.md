Este es un script vbs que abre busquedas y apliciones la verdad es muy corto solo usen esto para bromas
